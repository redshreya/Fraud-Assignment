// =====================================================================
// SOCIAL NETWORK ANALYSIS - NEO4J SCRIPT
// Run each block separately in Neo4j Query (Ctrl/Cmd+Enter).
// After running setup, expect 20 nodes and 32 relationships.
// =====================================================================

// ---------- 0. RESET (run first; also use before re-running setup) ----------
MATCH (n) DETACH DELETE n;

// ---------- 1. Users ----------
CREATE
(:User {name:'Rahul', age:29, city:'Pune', profession:'Data Scientist', activityLevel:92, influenceScore:87}),
(:User {name:'Priya', age:27, city:'Mumbai', profession:'AI Engineer', activityLevel:88, influenceScore:82}),
(:User {name:'Amit', age:31, city:'Pune', profession:'Entrepreneur', activityLevel:76, influenceScore:79}),
(:User {name:'Neha', age:25, city:'Delhi', profession:'Researcher', activityLevel:95, influenceScore:91}),
(:User {name:'Karan', age:30, city:'Pune', profession:'Software Engineer', activityLevel:69, influenceScore:73}),
(:User {name:'Sneha', age:28, city:'Mumbai', profession:'Product Manager', activityLevel:84, influenceScore:86}),
(:User {name:'Arjun', age:26, city:'Bengaluru', profession:'ML Engineer', activityLevel:91, influenceScore:89}),
(:User {name:'Meera', age:32, city:'Delhi', profession:'Consultant', activityLevel:72, influenceScore:77});

// ---------- 2. Friendships ----------
MATCH
(r:User {name:'Rahul'}), (p:User {name:'Priya'}), (a:User {name:'Amit'}), (n:User {name:'Neha'}),
(k:User {name:'Karan'}), (s:User {name:'Sneha'}), (ar:User {name:'Arjun'}), (m:User {name:'Meera'})
CREATE
(r)-[:FRIEND {since:2021, strength:0.91}]->(p),
(r)-[:FRIEND {since:2022, strength:0.75}]->(a),
(r)-[:FRIEND {since:2023, strength:0.64}]->(k),
(p)-[:FRIEND {since:2022, strength:0.83}]->(n),
(p)-[:FRIEND {since:2021, strength:0.89}]->(s),
(n)-[:FRIEND {since:2023, strength:0.71}]->(ar),
(n)-[:FRIEND {since:2022, strength:0.68}]->(m),
(a)-[:FRIEND {since:2024, strength:0.62}]->(k),
(s)-[:FRIEND {since:2023, strength:0.77}]->(ar),
(ar)-[:FRIEND {since:2024, strength:0.66}]->(m);

// ---------- 3. Groups ----------
CREATE
(:Group {name:'Artificial Intelligence', category:'Technology', members:420}),
(:Group {name:'Data Science', category:'Technology', members:350}),
(:Group {name:'Startup Founders', category:'Business', members:210});

// ---------- 4. Group membership ----------
MATCH
(r:User {name:'Rahul'}), (p:User {name:'Priya'}), (n:User {name:'Neha'}), (a:User {name:'Amit'}),
(s:User {name:'Sneha'}), (ar:User {name:'Arjun'}),
(g1:Group {name:'Artificial Intelligence'}), (g2:Group {name:'Data Science'}),
(g3:Group {name:'Startup Founders'})
CREATE
(r)-[:MEMBER_OF {role:'Member', since:2022}]->(g1),
(r)-[:MEMBER_OF {role:'Moderator', since:2021}]->(g2),
(p)-[:MEMBER_OF {role:'Member', since:2023}]->(g1),
(p)-[:MEMBER_OF {role:'Member', since:2022}]->(g2),
(n)-[:MEMBER_OF {role:'Researcher', since:2021}]->(g1),
(n)-[:MEMBER_OF {role:'Member', since:2023}]->(g2),
(a)-[:MEMBER_OF {role:'Founder', since:2022}]->(g3),
(s)-[:MEMBER_OF {role:'Member', since:2023}]->(g1),
(ar)-[:MEMBER_OF {role:'Member', since:2022}]->(g1),
(ar)-[:MEMBER_OF {role:'Member', since:2023}]->(g2);

// ---------- 5. Comments ----------
CREATE
(:Comment {id:'C001', text:'Graph databases are very useful for connected data.', sentiment:'Positive', toxicity:0.02, likes:34, timestamp:'2026-08-20'}),
(:Comment {id:'C002', text:'I think Graph RAG can improve knowledge retrieval.', sentiment:'Positive', toxicity:0.01, likes:41, timestamp:'2026-08-21'}),
(:Comment {id:'C003', text:'The performance depends heavily on the graph structure.', sentiment:'Neutral', toxicity:0.03, likes:18, timestamp:'2026-08-21'}),
(:Comment {id:'C004', text:'Interesting perspective on community detection.', sentiment:'Positive', toxicity:0.00, likes:29, timestamp:'2026-08-22'}),
(:Comment {id:'C005', text:'I disagree with this approach.', sentiment:'Negative', toxicity:0.12, likes:9, timestamp:'2026-08-22'});

// ---------- 6. Who commented ----------
MATCH
(r:User {name:'Rahul'}), (p:User {name:'Priya'}), (n:User {name:'Neha'}), (a:User {name:'Amit'}), (s:User {name:'Sneha'}),
(c1:Comment {id:'C001'}), (c2:Comment {id:'C002'}), (c3:Comment {id:'C003'}), (c4:Comment {id:'C004'}), (c5:Comment {id:'C005'})
CREATE
(r)-[:COMMENTED {time:'10:30'}]->(c1),
(p)-[:COMMENTED {time:'11:10'}]->(c2),
(n)-[:COMMENTED {time:'12:15'}]->(c3),
(a)-[:COMMENTED {time:'13:20'}]->(c4),
(s)-[:COMMENTED {time:'14:05'}]->(c5);

// ---------- 7. Replies ----------
MATCH
(p:User {name:'Priya'}), (n:User {name:'Neha'}),
(c1:Comment {id:'C001'}), (c3:Comment {id:'C003'})
CREATE
(p)-[:REPLIED_TO]->(c1),
(n)-[:REPLIED_TO]->(c1),
(p)-[:REPLIED_TO]->(c3);

// ---------- 8. Topics ----------
CREATE
(:Topic {name:'Graph Database'}),
(:Topic {name:'Graph RAG'}),
(:Topic {name:'Community Detection'}),
(:Topic {name:'Social Network Analysis'});

// ---------- 9. Comment -> Topic ----------
MATCH
(c1:Comment {id:'C001'}), (c2:Comment {id:'C002'}), (c3:Comment {id:'C003'}), (c4:Comment {id:'C004'}),
(t1:Topic {name:'Graph Database'}), (t2:Topic {name:'Graph RAG'}), (t3:Topic {name:'Community Detection'})
CREATE
(c1)-[:ABOUT]->(t1),
(c2)-[:ABOUT]->(t2),
(c3)-[:ABOUT]->(t1),
(c4)-[:ABOUT]->(t3);

// ---------- Sanity check: expect 20 nodes, 32 relationships ----------
MATCH (n) WITH count(n) AS nodes
MATCH ()-[r]->() RETURN nodes, count(r) AS relationships;


// =====================================================================
// EXERCISES
// Graph view: set captions User/Group/Topic = name, Comment = id.
// =====================================================================

// Ex 1 - Complete user network
MATCH (u:User)-[r]->(v:User)
RETURN u, r, v;

// Ex 2 - Friendships only
MATCH (u:User)-[r:FRIEND]->(f:User)
RETURN u, r, f;

// Ex 3 - Rahul's one-hop ego network
MATCH (r:User {name:'Rahul'})-[f:FRIEND]-(friend:User)
RETURN r, f, friend;

// Ex 4 - Friends-of-friends: exactly 2 hops, excluding direct friends
MATCH path = (r:User {name:'Rahul'})-[:FRIEND*2]-(fof:User)
WHERE fof <> r AND NOT (r)-[:FRIEND]-(fof)
RETURN path;

// Ex 5 - One to three hops
MATCH path = (r:User {name:'Rahul'})-[:FRIEND*1..3]-(other:User)
WHERE other <> r
RETURN path;

// Ex 6 - All friendship paths between Rahul and Karan
MATCH path = (r:User {name:'Rahul'})-[:FRIEND*1..4]-(k:User {name:'Karan'})
RETURN path;

// Ex 7a - Shortest connection between two chosen users (change names as needed)
MATCH (a:User {name:'Rahul'}), (b:User {name:'Meera'})
MATCH path = shortestPath((a)-[:FRIEND*]-(b))
RETURN path;

// Ex 7b - Shortest connection (table version)
MATCH (a:User {name:'Rahul'}), (b:User {name:'Meera'})
MATCH path = shortestPath((a)-[:FRIEND*]-(b))
RETURN [n IN nodes(path) | n.name] AS route, length(path) AS hops;

// Ex 8a - Longest simple path (no user repeated) across the whole network
MATCH path = (a:User)-[:FRIEND*]-(b:User)
WHERE a <> b
  AND all(n IN nodes(path) WHERE size([m IN nodes(path) WHERE m = n]) = 1)
RETURN path
ORDER BY length(path) DESC
LIMIT 1;

// Ex 8b - Longest of all shortest paths (network diameter), graph view
MATCH (a:User {name:'Amit'}), (b:User {name:'Arjun'})
MATCH path = shortestPath((a)-[:FRIEND*]-(b))
RETURN path;

// Ex 8b - Network diameter (table: top pairs by shortest-path length)
MATCH (a:User), (b:User)
WHERE elementId(a) < elementId(b)
MATCH path = shortestPath((a)-[:FRIEND*]-(b))
RETURN a.name AS from, b.name AS to, length(path) AS hops
ORDER BY hops DESC
LIMIT 4;

// Ex 9 - Users and groups
MATCH (u:User)-[m:MEMBER_OF]->(g:Group)
RETURN u, m, g;

// Ex 10 - Users and their comments
MATCH (u:User)-[c:COMMENTED]->(cm:Comment)
RETURN u, c, cm;

// Ex 11 - Comment conversation network (author + repliers)
MATCH (replier:User)-[r:REPLIED_TO]->(c:Comment)<-[cm:COMMENTED]-(author:User)
RETURN replier, r, c, cm, author;

// Ex 12 - Users, comments and topics
MATCH (u:User)-[c:COMMENTED]->(cm:Comment)-[a:ABOUT]->(t:Topic)
RETURN u, c, cm, a, t;

// Ex 13 - Shared topic network (graph view)
MATCH (u1:User)-[cm1:COMMENTED]->(c1:Comment)-[a1:ABOUT]->(t:Topic)<-[a2:ABOUT]-(c2:Comment)<-[cm2:COMMENTED]-(u2:User)
WHERE u1.name < u2.name
RETURN u1, cm1, c1, a1, t, a2, c2, cm2, u2;

// Ex 13 - Shared topic network (table version)
MATCH (u1:User)-[:COMMENTED]->(c1:Comment)-[:ABOUT]->(t:Topic)<-[:ABOUT]-(c2:Comment)<-[:COMMENTED]-(u2:User)
WHERE u1.name < u2.name
RETURN t.name AS topic, u1.name AS user1, u2.name AS user2;

// Ex 14 - High-toxicity interaction (threshold 0.1)
MATCH (u:User)-[cm:COMMENTED]->(c:Comment)
WHERE c.toxicity > 0.1
OPTIONAL MATCH (r:User)-[rp:REPLIED_TO]->(c)
RETURN u, cm, c, r, rp;

// Ex 15a - Friend recommendation graph for Rahul
MATCH (u:User {name:'Rahul'})-[f1:FRIEND]-(mutual:User)-[f2:FRIEND]-(rec:User)
WHERE rec <> u AND NOT (u)-[:FRIEND]-(rec)
RETURN u, f1, mutual, f2, rec;

// Ex 15b - Friend recommendations (table version)
MATCH (u:User {name:'Rahul'})-[:FRIEND]-(mutual:User)-[:FRIEND]-(rec:User)
WHERE rec <> u AND NOT (u)-[:FRIEND]-(rec)
RETURN rec.name AS recommended, collect(mutual.name) AS mutualFriends, count(mutual) AS mutualCount
ORDER BY mutualCount DESC;

// Ex 16 - Complete social interaction graph (includes isolated nodes)
MATCH (n)
OPTIONAL MATCH (n)-[r]->(m)
RETURN n, r, m;
